#ifndef Pino_H_
#define Pino_H_

#include "Conjunto.h"
#include "Cilindro.h"
#include "Disco.h"

class Pino : public Conjunto {
public:
	Pino();
};
#endif