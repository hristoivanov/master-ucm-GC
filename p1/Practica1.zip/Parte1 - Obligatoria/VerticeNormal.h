 
#ifndef VerticeNormal_H_
#define VerticeNormal_H_
 
class VerticeNormal {
	private:
		int iv, in;
    public:
        VerticeNormal(int iv, int in);
        ~VerticeNormal();
        int getIV();
        int getIN();
};
#endif
