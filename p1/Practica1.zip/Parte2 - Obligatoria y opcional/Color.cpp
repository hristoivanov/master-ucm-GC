#include "Color.h"

Color::Color(float red, float green, float blue) {
	this->red = red;
	this->green = green;
	this->blue = blue;
}

Color::Color() {
	this->red = 0.5f;
	this->green = 0.5f;
	this->blue = 0.5f;
}


