#ifndef Roble_H_
#define Roble_H_

#include "Conjunto.h"
#include "Cilindro.h"
#include "Disco.h"
#include "Esfera.h"

class Roble : public Conjunto {
public:
	Roble();
};
#endif