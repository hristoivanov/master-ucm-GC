#ifndef Abeto_H_
#define Abeto_H_

#include "Conjunto.h"
#include "Cilindro.h"
#include "Disco.h"

class Abeto : public Conjunto {
public:
	Abeto();
};
#endif