#ifndef Alamo_H_
#define Alamo_H_

#include "Conjunto.h"
#include "Cilindro.h"
#include "Disco.h"
#include "Esfera.h"

class Alamo : public Conjunto {
public:
	Alamo();
};
#endif