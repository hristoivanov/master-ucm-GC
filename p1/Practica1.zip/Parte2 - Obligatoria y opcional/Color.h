#ifndef Color_H_
#define Color_H_


class Color {
protected:
	float red;
	float green;
	float blue;

public:
	Color(float red, float green, float blue);
	Color();
};
#endif